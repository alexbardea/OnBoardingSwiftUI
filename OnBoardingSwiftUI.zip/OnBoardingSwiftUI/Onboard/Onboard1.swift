//
//  ContentView.swift
//
//
//  Created by Alexandru Bardea on 13/03/2021.
//

import SwiftUI

struct Onboard1: View {
    var body: some View {
        WalkthroughScreen()
    }
}

struct Onboard1_Previews: PreviewProvider {
    static var previews: some View {
        Onboard1()
    }
}
// home page

struct Home: View {
    var body: some View{
        
        Text("Welcome to home section")
            .font(.title)
            .fontWeight(.heavy)
        
    }
}

extension Color {
    
    static let lightBlue = Color.init(red: 182/255, green: 230/255, blue: 255/255)
    
}

extension UIScreen {
    static let screenWidth = UIScreen.main.bounds.size.width
    static let screenHeight = UIScreen.main.bounds.size.height
    static let screenSize = UIScreen.main.bounds.size
    
    
}

//walkthrough screen
struct WalkthroughScreen: View {
    var body: some View {
        
        //slide animation
        
        ZStack{
            
            Image("ornaments")
                .resizable()
                .scaledToFit()
                .offset(y: -275)
            
            Circle()
                .fill(Color.lightBlue)
                .frame(width: UIScreen.screenWidth, height: UIScreen.screenHeight)
                .scaleEffect(1.5)
                .offset(y: -530)
                .opacity(0.3)
            
          

            
            VStack(spacing: 20){
                
                Image("onboard1")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .offset(y: 35)
                
                HStack{
                    
                
                    Spacer()
                    
                    Button(action: /*@START_MENU_TOKEN@*/{}/*@END_MENU_TOKEN@*/, label: {
                        Text("Skip")
                            .fontWeight(.semibold)
                            .kerning(1.2)
                            
                    })
                  
                    .offset(x:-5, y:-345)}
                .foregroundColor(.black)
                .padding()
                
                
                Text("Welcome to Augmented Reality")
                    .font(/*@START_MENU_TOKEN@*/.title2/*@END_MENU_TOKEN@*/)
                    .fontWeight(.bold)
                    .foregroundColor(.black)
                    .padding(.top)
                    .offset(y:-105)
           
                Text("An educational application in iOS where you can interact with 3D objects introduced into space using the camera by module ARKit and Live Tracking in Xcode.")
                    .fontWeight(.thin)
                    .foregroundColor(.black)
                    //.kerning(0.4)
                    .frame(width: 345.0, height: 95.0)
                    .multilineTextAlignment(.center)
                    .offset(y:-85)
               
                Image("onboard2")
                    .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 120)
                        .offset(y:-55)
                    
                Spacer(minLength: 100)
                
            }
            
            .background(Color("color1").ignoresSafeArea())
        }
        
//        .overlay(
        
            //Button
            
//            Button(action: /*@START_MENU_TOKEN@*/{}/*@END_MENU_TOKEN@*/, label: {
//
//
//                Image(systemName: "chevron.right")
//                    .font(.system(size: 24, weight: .semibold))
//                    .foregroundColor(.black)
//                    .frame(width: 55, height: 55)
//                    .background(Color.white)
//                    .clipShape(Circle())
//                    .offset(y: -60)
//
//                //Circular Slider
//
//                    .overlay(
//
//                        ZStack{
//                            Circle()
//                                .stroke(Color.black.opacity(0.04),lineWidth: 4)
//                                .offset(y: -60)
//
//
//                            Circle()
//                                .trim(from: 0, to: 0.3)
//                                .stroke(Color.black, lineWidth: 4)
//                                .rotationEffect(.init(degrees: -90))
//                                .offset(y: -60)
//                        }
//                        .padding(-15)
//
//                    )
//            })
 //           ,alignment: .bottom
//        )
        
    }
}
