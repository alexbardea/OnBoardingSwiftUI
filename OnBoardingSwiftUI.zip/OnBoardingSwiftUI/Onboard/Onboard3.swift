//
//  Onboarding3.swift
//
//
//  Created by Alexandru Bardea on 14/03/2021.
//

import SwiftUI

struct Onboard3: View {
    var body: some View {
        WalkthroughScreen3()
    }
}

struct Onboard3_Previews: PreviewProvider {
    static var previews: some View {
        Onboard3()
    }
}

//walkthrough screen
struct WalkthroughScreen3: View {
    var body: some View {
        
        //slide animation
        
        ZStack{
            
            
            VStack(spacing: 20){
                
             Image("onboard4")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .offset(y: 53)
                
                HStack{
                    
                
                    Spacer()
                .offset(x:-5, y:-345)}
                .foregroundColor(.black)
                .padding()
                
                
                Text("Use it...")
                    .font(/*@START_MENU_TOKEN@*/.title2/*@END_MENU_TOKEN@*/)
                    .fontWeight(.bold)
                    .foregroundColor(.black)
                    .padding(.top)
                    .offset(x:-125, y:-45)
           
                Text("You can walk around the room quietly, objects will not be lost. Don't forget to keep your social distance and especially to leave me feedback.")
                    .fontWeight(.thin)
                    .foregroundColor(.black)
              //      .frame(width: -1.0)
                    .frame(width: 345.0, height: 95.0)
                  //  .kerning(0.1)
                    
                //    .multilineTextAlignment(.center)
                    .offset(x:5, y:-55)
               
                
                    
                Spacer(minLength: 100)
                
            }
            
            .background(Color("color1").ignoresSafeArea())
        }
        
//        .overlay 
        
    }
}

