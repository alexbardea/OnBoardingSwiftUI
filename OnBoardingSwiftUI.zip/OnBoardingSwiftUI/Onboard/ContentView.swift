//
//  ContentView.swift
//
//
//  Created by Alexandru Bardea on 14/03/2021.
//

import SwiftUI

struct ContentView: View {
    
    @State var SlideGesture = CGSize.zero
    @State var SlideOne = false
    @State var SlideOnePrevious = false
    @State var SlideTwo = false
    @State var SlideTwoPrevious = false
    
    var body: some View {
        ZStack{
            
            Color(#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)).edgesIgnoringSafeArea(.all)
            
            Onboard3()
                .offset(x: SlideGesture.width)
                .offset(x: SlideTwo ? 0 : 500)
                .animation(.spring())
                        
                .gesture(
                    DragGesture().onChanged { value in
                        self.SlideGesture = value.translation
                    }
                    .onEnded { value in
                        if self.SlideGesture.width > 150 {
                            self.SlideTwo = false
                            self.SlideTwoPrevious = true
                        }
                        self.SlideGesture = .zero
                    }
                )
            
            
            Onboard2()
                .offset(x: SlideGesture.width)
                .offset(x: SlideOne ? 0 : 500)
                .offset(x: SlideOnePrevious ? 500 : 0)
                .offset(x: SlideTwo ? -500 : 0)
                .animation(.spring())
                
                .gesture(
                    DragGesture().onChanged { value in
                        self.SlideGesture = value.translation
                    }
                    .onEnded { value in
                        if self.SlideGesture.width < -150 {
                            self.SlideOne = true
                            self.SlideTwo = true
                            
                        }
                        
                        if self.SlideGesture.width > 150 {
                            self.SlideOnePrevious = true
                            self.SlideOne = false
                            
                        }
                        self.SlideGesture = .zero
                    }
                )
            
            
            
            
            Onboard1()
                .offset(x: SlideGesture.width)
                .offset(x: SlideOne ? -500 : 0)
                
                .animation(.spring())
                
                .gesture(
                    DragGesture().onChanged { value in
                        self.SlideGesture = value.translation
                    }
                    .onEnded { value in
                        if self.SlideGesture.width < -150 {
                            self.SlideOne = true
                            self.SlideOnePrevious = false
                        }
                        self.SlideGesture = .zero
                    }
                )
            
            //Stack
            
            
            VStack {
                Spacer()
                ZStack {
                   VStack {
                    Button(action: /*@START_MENU_TOKEN@*/{}/*@END_MENU_TOKEN@*/, label: {
                       
                        
                        Image(systemName: "chevron.right")
                            .font(.system(size: 24, weight: .semibold))
                            .foregroundColor(.black)
                            .frame(width: 55, height: 55)
                            .background(Color.lightBlue)
                            .clipShape(Circle())
                            .offset(y: -10)
                        
                        //Circular Slider
                         
                            .overlay(
                            
                                ZStack{
                                    Circle()
                                        .stroke(Color.black.opacity(0.04),lineWidth: 4)
                                        .offset(y: -10)
                                        
                                    
                                    Circle()
                                        .trim(from: 0, to: 1.0)
                                        .stroke(Color.black, lineWidth: 4)
                                        .rotationEffect(.init(degrees: 90))
                                        .offset(y: -10)
                                }
                                .padding(-15)
                            
                            )
                    })
                    
                    
//                        Text("Complete")
//                            .font(.system(size: 17, weight: .medium, design: .rounded))
//                            .foregroundColor(Color.white)
//                    }
//                    .frame(width: 140, height: 40)
//                    .background(Color.green)
//                    .cornerRadius(20)
                    .animation(.spring())
                    .offset(x: SlideTwo ? 0 : 500)
                    
                    VStack {
                        Button(action: /*@START_MENU_TOKEN@*/{}/*@END_MENU_TOKEN@*/, label: {
                           
                            
                            Image(systemName: "chevron.right")
                                .font(.system(size: 24, weight: .semibold))
                                .foregroundColor(.black)
                                .frame(width: 55, height: 55)
                                .background(Color.white)
                                .clipShape(Circle())
                                .offset(y: -60)
                            
                            //Circular Slider
                             
                                .overlay(
                                
                                    ZStack{
                                        Circle()
                                            .stroke(Color.black.opacity(0.04),lineWidth: 4)
                                            .offset(y: -60)
                                            
                                        
                                        Circle()
                                            .trim(from: 0, to: 0.3)
                                            .stroke(Color.black, lineWidth: 4)
                                            .rotationEffect(.init(degrees: -90))
                                            .offset(y: -60)
                                    }
                                    .padding(-15)
                                
                                )
                        })
                    }
                    //.frame(width: 140, height: 40)
                    //.background(Color.black)
                   // .cornerRadius(20)
                    .animation(.spring())
                    .offset(x: SlideTwo ? -500 : 0)
                    
                } .offset(y:-20)
            }
            
//            VStack {
//                Spacer()
//                ZStack {
//                    VStack {
//                        Text("Complete")
//                            .font(.system(size: 17, weight: .medium, design: .rounded))
//                            .foregroundColor(Color.white)
//                    }
//                    .frame(width: 140, height: 40)
//                    .background(Color.green)
//                    .cornerRadius(20)
//                    .animation(.spring())
//                    .offset(x: SlideTwo ? 0 : 500)
//
//                    VStack {
//                        Text("Skip")
//                            .font(.system(size: 17, weight: .medium, design: .rounded))
//                            .foregroundColor(Color.white)
//                    }
//                    .frame(width: 140, height: 40)
//                    .background(Color.black)
//                    .cornerRadius(20)
//                    .animation(.spring())
//                    .offset(x: SlideTwo ? -500 : 0)
//
//                } .offset(y:-70)
//            }
            
            
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
}
