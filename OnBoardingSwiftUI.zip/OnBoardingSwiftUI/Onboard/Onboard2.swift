//
//  OnboardingTwo.swift
//
//
//  Created by Alexandru Bardea on 14/03/2021.
//

import SwiftUI

struct Onboard2: View {
    var body: some View {
        WalkthroughScreen2()
    }
}

struct Onboard2_Previews: PreviewProvider {
    static var previews: some View {
        Onboard2()
    }
}



//walkthrough screen
struct WalkthroughScreen2: View {
    var body: some View {
        
        //slide animation
        
        ZStack{
            
            
            
          

            
            VStack(spacing: 20){
                
                Image("onboard3")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .offset(y: 53)
                
                HStack{
                    
                
                    Spacer()
                    
                  
                  
                    .offset(x:-5, y:-345)}
                .foregroundColor(.black)
                .padding()
                
                
                Text("How does it work?")
                    .font(/*@START_MENU_TOKEN@*/.title2/*@END_MENU_TOKEN@*/)
                    .fontWeight(.bold)
                    .foregroundColor(.black)
                    .padding(.top)
                    .offset(y:-5)
           
                Text("The application uses the external camera to be able to find tracking points and to be able to interact more easily.")
                    .fontWeight(.thin)
                    .foregroundColor(.black)
                    .frame(width: 345.0, height: 95.0)
                   // .kerning(0.1)
                    .multilineTextAlignment(.center)
                    .offset(y:-5)
               
                
                    
                Spacer(minLength: 100)
                
            }
            
            .background(Color("color1").ignoresSafeArea())
        }
        
//        .overlay(
//        
//            //Button
//            
//            Button(action: /*@START_MENU_TOKEN@*/{}/*@END_MENU_TOKEN@*/, label: {
//               
//                
//                Image(systemName: "chevron.right")
//                    .font(.system(size: 24, weight: .semibold))
//                    .foregroundColor(.black)
//                    .frame(width: 55, height: 55)
//                    .background(Color.white)
//                    .clipShape(Circle())
//                    .offset(y: -60)
//                
//                //Circular Slider
//                 
//                    .overlay(
//                    
//                        ZStack{
//                            Circle()
//                                .stroke(Color.black.opacity(0.04),lineWidth: 4)
//                                .offset(y: -60)
//                                
//                            
//                            Circle()
//                                .trim(from: 0, to: 0.3)
//                                .stroke(Color.black, lineWidth: 4)
//                                .rotationEffect(.init(degrees: -90))
//                                .offset(y: -60)
//                        }
//                        .padding(-15)
//                    
//                    )
//            })
//            ,alignment: .bottom
//        )
        
    }
}
